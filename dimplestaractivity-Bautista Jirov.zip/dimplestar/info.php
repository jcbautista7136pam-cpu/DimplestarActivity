<?php
	include 'php_includes/connection.php';
?>
<html>
	<head>
	</head>
	<body>
		<?php
			include 'php_includes/info.php';
		?>
	</body>
</html>