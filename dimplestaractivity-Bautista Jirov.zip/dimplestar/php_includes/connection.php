<?php
	session_start();
	$conn = mysqli_connect("localhost", "root", null, "dimplestar");
?>