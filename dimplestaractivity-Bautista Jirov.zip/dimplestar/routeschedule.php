<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
<style>
  #mainnav {
    list-style: none;
    margin: 0 auto;
    padding: 12px 0;
    background: #006400;
    text-align: center;
    border-radius: 10px;
    display: inline-block;
    box-shadow: 0 4px 6px rgba(0,0,0,0.3);
    position: relative;
    top: 10px;
    z-index: 2;
  }

  #mainnav li {
    display: inline-block;
    margin: 0 10px;
  }

  #mainnav a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    padding: 10px 20px;
    border-radius: 5px;
    transition: background 0.3s ease, transform 0.2s ease;
  }

  #mainnav li.current a {
    background: black;
  }

  #mainnav a:not(.current) {
    background: transparent;
  }

  #mainnav a:not(.current):hover {
    background: #228B22;
    transform: scale(1.05);
    color: #fff;
  }

  #gallerycontainer > div {
    background-color: #006400;
    border-radius: 10px;
    padding: 20px;
    color: white;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-size: 16px;
    line-height: 1.6;
  }

  table td, table h3 {
    color: white;
    font-size: 16px;
  }

  .routes-title-bar {
    background-color: #ECBD2F;
    color: white;
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    border-radius: 5px;
    margin-bottom: 20px;
    padding: 4px 0;
  }
</style>
</head>
<body style="background: #474544 url('images/bus.jpg') no-repeat top center; background-size: cover;">

<div id="wrapper">
  <div id="header">
    <h1>
      <a href="index.php">
        <img src="images/DSL.png" alt="Dimple Star Transport"
             style="position:absolute; top:5px; left:100px; border-radius:50%; object-fit:cover; z-index:99;" />
      </a>
    </h1>
    <ul id="mainnav">
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="terminal.php">Terminals</a></li>
      <li class="current"><a href="routeschedule.php">Routes / Schedules</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="book.php">Book Now</a></li>
    </ul>
  </div>

  <div id="content">
    <div id="gallerycontainer">
      <div style="margin:0 auto; padding:30px 20px; width:820px;">
        <div class="routes-title-bar">ROUTES / SCHEDULES</div>
        <br>
        <img src="images/route.png" width="820" style="display:block; margin:0 auto;"><br>
        <h2 style="text-align:center;">(All trips are vice versa)</h2>
        <hr>

        <table style="width:70%; margin:0 auto; border-collapse: collapse;">
          <tr>
            <td><h3>Origin</h3></td>
            <td><h3>Regular Schedule</h3></td>    
            <td><h3>Destination</h3></td>
          </tr>
          <tr>
            <td>Ali Mall Cubao Terminal</td>
            <td>9:00 am / 10:00 am / 1:00 pm / 4:00pm</td>    
            <td>San Jose</td>
          </tr>
          <tr>
            <td>Alabang Terminal</td>
            <td>6:00 am / 7:00 am / 2:00 pm / 6:00 pm / 10:00 pm</td>    
            <td>San Jose</td>
          </tr>
          <tr>
            <td>Cabuyao Terminal</td>
            <td>8:00 am / 9:00 am / 4:00 pm / 8:00 pm</td>        
            <td>San Jose</td>
          </tr>
          <tr>
            <td>Espana Terminal</td>
            <td>4:30 am / 5:30 am / 12:00 am / 4:00 pm / 8:00 pm</td>    
            <td>San Jose</td>
          </tr>
          <tr>
            <td>San Lazaro Terminal</td>
            <td>3:00 am / 4:30 am / 11:00 am / 3:00 pm / 7:00 pm</td>    
            <td>San Jose</td>
          </tr>
          <tr>
            <td>Pasay Terminal</td>
            <td>5:00 am / 6:00 am / 1:00 pm / 3:00pm</td>    
            <td>San Jose</td>
          </tr>
        </table>

        <div class="column-clear"></div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>

  <div id="footer">
    <a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
    <p>&copy;Dimple Star Transport<br /></p>
  </div>
</div>
</body>
</html>
